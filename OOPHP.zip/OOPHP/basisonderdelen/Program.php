<?php
include 'Person.php';
$umut = new Person("Umut", 18, "M");
unset($umut);
$demirel = new Person("Demirel", 19, "F");
$mohammed = new Person("Mohammed", 19, "M");
$thamara = new Person("Thamara", 18, "F");
$jan = new Person("Jan", 21, "M");

?>


